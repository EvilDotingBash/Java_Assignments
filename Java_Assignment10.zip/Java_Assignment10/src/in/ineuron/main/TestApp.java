package in.ineuron.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class TestApp {

	public static void main(String[] args) {
		
		List<Integer> list = new ArrayList<>();
		
		System.out.println("Enter the number of integers to be stored :: ");
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		
		System.out.println("Enter "+size + " integers :: ");
		for (int i = 0; i < size; i++) {
			list.add(sc.nextInt());
		}
		if (size<2) {
			throw new IllegalArgumentException("List must contain more than 2 elements");
		}
		Iterator iterator = list.iterator(); 
		for (Integer integer : list) {
			System.out.print(integer+"\t");
		}
		Collections.sort(list);
		System.out.println();
		for (Integer integer : list) {
			System.out.print(integer+"\t");
		}
		System.out.println("\nSecond Largest Element in the list :: "+list.get(size-2));
		System.out.println("Second Smallest Element in the list :: "+list.get(1));
		
	}

}
