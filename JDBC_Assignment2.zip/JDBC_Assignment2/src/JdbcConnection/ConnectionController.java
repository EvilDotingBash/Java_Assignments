package JdbcConnection;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class ConnectionController {

	public static Connection getJdbcConnection() throws SQLException, IOException {
		
		FileInputStream fis = new FileInputStream("D:\\Assignment\\JDBC_Assignment2\\src\\application.properties");
		Properties properties = new Properties();
		properties.load(fis);
		String url = properties.getProperty("url");
		String user = properties.getProperty("user");;
		String password = properties.getProperty("password");;
		Connection connection = DriverManager.getConnection(url, user, password);
		return connection;		
	}
	
	public static void cleanup(Connection conn, Statement stmt, ResultSet resultSet) throws SQLException {
		if(conn != null)
			conn.close();
		if (stmt != null) {
			stmt.close();
		}
		if (resultSet != null) {
			resultSet.close();
		}
	}
}