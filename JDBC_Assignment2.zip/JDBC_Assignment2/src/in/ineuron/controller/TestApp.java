package in.ineuron.controller;

import java.util.Scanner;

import in.ineuron.dto.Student;
import in.ineuron.service.IStudentService;
import in.ineuron.servicefactory.StudentServiceFactory;

public class TestApp {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		while(true) {
			
			System.out.println("1. INSERT STUDENT DATA");
			System.out.println("2. SELECT STUDENT DATA");
			System.out.println("3. DELETE STUDENT DATA");
			System.out.println("4. UPDATE STUDENT DATA");
			System.out.println("5. EXIT");
			System.out.print("Enter your choice :: ");
			int ch = scan.nextInt();
			
			switch (ch) {
			case 1: insertOperation();
					break;
			case 2: selectOperation();
					break;
			case 3: deleteOperation();
					break;
			case 4: updateOperation();
					break;
			case 5: System.out.println("Thanks for using the application :: ");
					System.exit(0);
			default: System.out.println("Wrong choice...");
					break;
			}
		}
		
	}
	
	private static void updateOperation() {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the sid you want to update");
		int id = scan.nextInt();
		
		IStudentService stdService = StudentServiceFactory.getStudentService();
		Student std = stdService.searchStudent(id);
		
		if (std!=null) {
			System.out.println(std);
			System.out.println("Old name is ");
			System.out.print(std.getSname());
			System.out.println("Enter the new name");
			String newName = scan.next();
			
			System.out.println("Old age is ");
			System.out.println(std.getSage());
			System.out.println("Enter the new age");
			Integer newAge = scan.nextInt();
			
			System.out.println("Old address is ");
			System.out.println(std.getSaddress());
			System.out.println("Enter the new address");
			String newAddress = scan.next();
			
			String stdNew = stdService.updateStudent(id, newName, newAge, newAddress);
			if (stdNew.equalsIgnoreCase("success")) {
				System.out.println("Record Updated successfully");
			}else {
				System.out.println("Record not updated ");
			}
			
		}else {
			System.out.println("Record not found for the given id "+id);
		}
	}

	private static void deleteOperation() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id to be deleted :: ");
		int sid = sc.nextInt();
		
		IStudentService stdService = StudentServiceFactory.getStudentService();
		String msg = stdService.deleteStudent(sid);
		if (msg.equalsIgnoreCase("success")) {
			System.out.println("Record deleted successfully");
		}else if (msg.equalsIgnoreCase("not found")) {
			System.out.println("Record not found for given sid "+ sid);
		} else {
			System.out.println("Record deletion failed ");
		}
	}

	private static void selectOperation() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the sid ");
		int sid = sc.nextInt();
		
		IStudentService stdService = StudentServiceFactory.getStudentService();
		Student std = stdService.searchStudent(sid);
		
		if (std!=null) {
			System.out.println(std);
			System.out.println("ID\tNAME\tAGE\tADDRESS");
			System.out.println(std.getSid()+"\t"+std.getSname()+"\t"+std.getSage()+"\t"+std.getSaddress());
		}else {
			System.out.println("Record not found for the given id "+sid);
		}
	}
	
	private static void insertOperation() {
		IStudentService stdService = StudentServiceFactory.getStudentService();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name ");
		String sname = sc.next();
		
		System.out.println("Enter the age ");
		Integer sage = sc.nextInt();
		
		System.out.println("Enter the address ");
		String saddress = sc.next();
		
		String msg = stdService.addStudent(sname, sage, saddress);
		
		if (msg.equalsIgnoreCase("success")) {
			System.out.println("Records inserted successfully");
		} else {
			System.out.println("Record insertion failed");
		}
			
	}
}