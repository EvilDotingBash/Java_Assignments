package in.ineuron.commons;

public abstract class Animal {

	private String name;

	public Animal() {
		this.name = "bella";
	}

	public Animal(String name) {
		this.name = name;
	}

	public abstract void sound();
	public abstract void breed();
	public void sleep() {
		System.out.println(name + " is sleeping");
	}
}
