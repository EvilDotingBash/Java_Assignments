package in.ineuron.commons;

public class Dog extends Animal{

	public Dog() {
		super();
	}
	public Dog(String name) {
		super(name);
	}
	@Override
	public void sound() {
		System.out.println("Dog Barks");	
	}

	@Override
	public void breed() {
		System.out.println("Dogs breed is German shepherd");
		
	}

}
