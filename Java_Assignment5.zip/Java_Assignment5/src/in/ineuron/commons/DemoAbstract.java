package in.ineuron.commons;

public class DemoAbstract {

	public static void main(String[] args) {
		
		Animal dog = new Dog();
		dog.sound();
		dog.breed();
		dog.sleep();
		System.out.println();
		Animal dog2 = new Dog("buddy");
		dog2.sound();
		dog2.breed();
		dog2.sleep();
	}

}
