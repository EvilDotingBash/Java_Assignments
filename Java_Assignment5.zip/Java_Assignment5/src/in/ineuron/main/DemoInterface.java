package in.ineuron.main;

public class DemoInterface {

	public static void main(String[] args) {
		IAnimal dog = new Dog();
		PetAnimal dog1 = new Dog();
		System.out.println("Dog's Name is "+dog.dogsName);
		dog.sound();
		dog.breed();
		dog.sleep();
		dog1.domestic();
	}

}
