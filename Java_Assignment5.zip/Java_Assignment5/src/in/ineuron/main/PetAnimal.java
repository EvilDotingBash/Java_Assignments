package in.ineuron.main;

public abstract class PetAnimal {

	public abstract void domestic();
	
}