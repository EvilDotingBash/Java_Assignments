package in.ineuron.main;

public class Dog extends PetAnimal implements IAnimal {

	@Override
	public void sound() {
		System.out.println("Dog Barks");

	}

	@Override
	public void domestic() {
		System.out.println("Dog is a domestic Animal");
	}

	@Override
	public void breed() {
		System.out.println("Dogs breed is German shepherd");
		
	}
}
