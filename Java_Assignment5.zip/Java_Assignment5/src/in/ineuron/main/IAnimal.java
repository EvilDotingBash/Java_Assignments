package in.ineuron.main;

public interface IAnimal {

	public static final String dogsName = "bella";
	public void sound();
	public void breed();
	default void sleep() {
		System.out.println("Animal is sleeping");
	}
}
