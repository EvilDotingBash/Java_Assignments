package in.ineuron.dao;

import org.springframework.data.repository.CrudRepository;

import in.ineuron.bo.Product;

public interface IProductRepo extends CrudRepository<Product, Long> {

}
