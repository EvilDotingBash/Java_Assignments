package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import in.ineuron.bo.Product;
import in.ineuron.service.IProductMgmtService;

@SpringBootApplication
public class DaoSpringDataJpa01Application {

	public static void main(String[] args) {
		ApplicationContext factory = SpringApplication.run(DaoSpringDataJpa01Application.class, args);
		
		IProductMgmtService service = factory.getBean(IProductMgmtService.class);
		Product product = new Product(null, "fossil", "fossil", 6000, 3);
		String status = service.registerProduct(product);
		System.out.println(status);
		
		((ConfigurableApplicationContext) factory).close();
	}

}
