package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.bo.Product;
import in.ineuron.dao.IProductRepo;

@Service("service")
public class ProductMgmtSerciceImpl implements IProductMgmtService {

	@Autowired
	private IProductRepo productRepo;

	@Override
	public String registerProduct(Product product) {
		System.out.println("In Memory proxy class is :: " + productRepo.getClass().getName());

		Product saveProduct = null;
		if (product != null) {
			saveProduct = productRepo.save(product);
		}
		return saveProduct != null ? "product registered successfully " + saveProduct.getId()
				: "product registration failed";

	}

}
