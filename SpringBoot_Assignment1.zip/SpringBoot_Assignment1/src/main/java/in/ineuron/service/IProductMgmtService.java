package in.ineuron.service;

import in.ineuron.bo.Product;

public interface IProductMgmtService {

	public String registerProduct(Product product);
}
