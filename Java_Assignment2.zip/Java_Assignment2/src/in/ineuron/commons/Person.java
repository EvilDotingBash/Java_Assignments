package in.ineuron.commons;

public class Person {

	String name;
	int rollno;

	public Person() {
		name = "";
		rollno = 0;
	}

	
	public Person(int rollno, String name) {
		this.name = name;
		this.rollno = rollno;
	}

	
}
