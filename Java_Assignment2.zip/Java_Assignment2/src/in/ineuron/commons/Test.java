
package in.ineuron.commons;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		Student student = new Student();
		System.out.println("Default Constructor output");
		student.display();
		Scanner sc = new Scanner(System.in);
		System.out.println();
		System.out.println("Enter the rollno, name, marks :: ");
		int rollno = sc.nextInt();
		String name = sc.next();
		float marks = sc.nextFloat();
		Student student1 = new Student(rollno, name, marks);
		System.out.println("Parameterised Constructor output");
		student1.display();

	}

}
