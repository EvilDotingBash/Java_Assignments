package in.ineuron.commons;

public class Student extends Person {

	float marks;

	public Student() {
		// super();
		marks = (float) 0.0;
	}

	public Student(int rollno, String name, float marks) {
		super(rollno,name);
		this.marks = marks;
	}
	
	void display() {
		System.out.println("Roll No of student :: "+rollno);
		System.out.println("Name of student :: "+name);
		System.out.println("Marks of student :: "+marks);
		
	}
}
