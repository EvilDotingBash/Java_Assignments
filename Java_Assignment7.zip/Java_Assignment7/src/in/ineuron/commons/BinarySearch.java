package in.ineuron.commons;

public class BinarySearch {

	public static int bSearch(int[] a, int s) {

		int beg = 0, end = a.length - 1, mid = 0, pos = -1;
		while (beg <= end) {
			mid = (beg + end) / 2;
			if (s == a[mid]) {
				pos = mid;
				break;
			} else if (s < a[mid]) {
				end = mid - 1;
			} else {
				beg = mid + 1;
			}
		}
		return pos;
	}
}
