package in.ineuron.commons;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		System.out.println("Enter the size of array ::");
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		int a[] = new int[size];
		
		System.out.println("Enter the "+size+" elements of array :: ");
		for (int i = 0; i < a.length; i++) {
			a[i] = sc.nextInt();
		}
		SortArray.quickSort(a,0,(a.length)-1);
		
		System.out.println("Sorted Array :: ");
		display(a);
		System.out.println();
		System.out.println("Enter the element to be searched :: ");
		int s = sc.nextInt();
		int pos = BinarySearch.bSearch(a,s);
		
		if (pos == -1) {
			System.out.println("Target Value " + s + " not found in the array");
		} else {
			System.out.println("Target Value " + s + " found at index " + pos);
		}
		sc.close();
	}

	private static void display(int[] a) {
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i]+"\t");
		}	
	}
}
