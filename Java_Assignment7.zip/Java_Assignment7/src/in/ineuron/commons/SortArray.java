package in.ineuron.commons;

public class SortArray {

	
	public static void quickSort(int[] a, int beg, int end) {
		
		
		if (beg<end) {
			int p = partition(a,beg,end);
			quickSort(a, beg, p-1);
			quickSort(a, p+1, end);
		}
		//return a;
	}

	private static int partition(int[] a, int beg, int end) {
		
		int pivot = a[end];
		int i = beg-1;
		
		for (int j = beg; j < end; j++) {
			if (a[j]<pivot) {
				i++;
				int t = a[i];
				a[i] = a[j];
				a[j] = t;
				
			}
		}
		int temp = a[i+1];
		a[i+1] = a[end];
		a[end] = temp;
		return i+1;
	}
	
}
