package in.ineuron.main;

import java.io.IOException;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.ineuron.model.Employee;
import in.ineuron.util.HibernateUtil;

public class UpdateSelectApp {

	public static void main(String[] args) throws IOException {

		Session session = null;
		Transaction transaction = null;
		boolean flag = false;

		System.out.println("Enter the id you want to update");
		Scanner sc = new Scanner(System.in);
		Integer id = sc.nextInt();
		try {
			session = HibernateUtil.getSession();
			if (session != null) {
				transaction = session.beginTransaction();
			}
			if (transaction!=null) {
				
				Employee employee = new Employee();
				employee.setId(id);
				employee.setName("Virat");
				employee.setAge(35);
				employee.setSalary(40000);
				
				session.saveOrUpdate(employee);
				flag=true;
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (flag) {
				transaction.commit();		
				System.out.println("Object saved to database...");
			} else {
				transaction.rollback();
				System.out.println("Object not saved to database...");
			}
		}

		try {
			if (session != null) {
				Employee employee = session.get(Employee.class, id);
				if (employee != null) {
					System.out.println(employee);
				} else {
					System.out.println("Record not found for the given id :: " + id);
				}
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
			sc.close();
		}
		
	}

}