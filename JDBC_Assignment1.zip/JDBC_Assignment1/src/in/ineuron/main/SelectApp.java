package in.ineuron.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import JdbcConnection.ConnectionController;

public class SelectApp {

	public SelectApp() {
	}

	public static void main(String[] args) throws SQLException {
		
		PreparedStatement pstmt= null;
		ResultSet resultSet = null;
		String sqlSelectQuery = "Select id,name,age,address from students";
		Connection connection = ConnectionController.getJdbcConnection();
		if (connection != null) 
			pstmt = connection.prepareStatement(sqlSelectQuery);
		if(pstmt!=null)
			resultSet = pstmt.executeQuery();
		System.out.println("ID\tNAME\tAGE\tADDRESS");
		if (resultSet != null) {
			while (resultSet.next()) {
				System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getString(4));
			}
		}
		
	}
}