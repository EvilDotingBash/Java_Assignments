package in.ineuron.main;

import java.util.ArrayList;
import java.util.List;

public class StreamOperationDemo {

	public static void main(String[] args) {
		List<Employee> employees = new ArrayList<>();
		employees.add(new Employee(1,"Sachin",8000));
		employees.add(new Employee(2,"Rahul",7500));
		employees.add(new Employee(3,"Dhoni",8600));
		employees.add(new Employee(4,"Virat",9000));
		employees.add(new Employee(5,"Gayle",8500));
		
		System.out.println("Sorted employees by salary (ascending order) :: ");
		System.out.println("EID\tNAME\tSALARY");
		employees.stream().sorted((e1,e2) -> Double.compare(e1.getSalary(), e2.getSalary()))
			.forEach(e-> System.out.println(e.getEid()+"\t"+e.getName()+"\t"+e.getSalary()));
	
		System.out.println("\nEmployees with salary greater than 8000");
		System.out.println("EID\tNAME\tSALARY");
		employees.stream()
			.filter(e ->e.getSalary()>8000)
			.forEach(e -> System.out.println(e.getEid()+"\t"+e.getName()+"\t"+e.getSalary()));
	}

}
