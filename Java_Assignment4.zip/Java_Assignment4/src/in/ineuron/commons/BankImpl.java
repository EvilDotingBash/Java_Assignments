package in.ineuron.commons;

public class BankImpl implements IBank {

	private double balance;

	@Override
	public void deposit(double amount) {
		balance = balance + amount;

	}

	@Override
	public void withdraw(double amount) {
		if(balance!=0)
			balance = balance - amount;
		else
			System.out.println("Balance is "+balance + " 1Can't withdraw right now...Please deposit money...");
	}

	@Override
	public void checkBalance() {
		System.out.println("Your Bank Balance is :: " + balance);
	}

}
