package in.ineuron.commons;

public interface IBank {
	
	public void deposit(double amount);
	public void withdraw(double amount);
	public void checkBalance();
	
}
