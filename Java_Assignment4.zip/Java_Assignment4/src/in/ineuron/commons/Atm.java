package in.ineuron.commons;

import java.util.Scanner;

public class Atm {

	public static void main(String[] args) {
		double amount;
		IBank bank = new BankImpl();
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to our bank...");
		while (true) {
			System.out.println("1. Deposit");
			System.out.println("2. Withdraw");
			System.out.println("3. Check Balance");
			System.out.println("4. Exit");
			System.out.println("Please Enter your choice :: ");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter the amount to deposit :: ");
				amount = sc.nextDouble();
				bank.deposit(amount);
				break;
			case 2:
				System.out.println("Enter the amount to withdraw :: ");
				amount = sc.nextDouble();
				bank.withdraw(amount);
				break;
			case 3:
				bank.checkBalance();
				break;
			case 4:
				System.out.println("Thanks for using our bank...");
				System.exit(0);
			default:
				System.out.println("Service not available...Please try again");
				break;
			}
		}
	}

}
