package in.ineuron.shape;

public interface IShape {

	void input();
	void area();
	void perimeter();
}
