package in.ineuron.shape;

public class Shape {

	public void shapes(IShape shape) {
		shape.input();
		shape.area();
		shape.perimeter();
	}
}
