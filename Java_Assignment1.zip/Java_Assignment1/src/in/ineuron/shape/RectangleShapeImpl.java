package in.ineuron.shape;

import java.util.Scanner;

public class RectangleShapeImpl implements IShape {

	
	private double length;
	private double breadth;

	@Override
	public void area() {
		
		double area = length*breadth;
		System.out.println("Area of rectangle for length " + length + " and breadth "+breadth+" is " + area);
	}

	@Override
	public void perimeter() {
		
		double perimeter = 2*(length+breadth);
		System.out.println("Perimeter of rectangle with length " + length + " and breadth "+breadth +" is " + perimeter);
	}

	@Override
	public void input() {
		System.out.println();
		System.out.println("Enter the length and breadth of rectangle :: ");
		Scanner sc = new Scanner(System.in);
		length = sc.nextDouble();
		breadth = sc.nextDouble();	
		
	}

	

	

}
