package in.ineuron.shape;

import java.util.Scanner;

public class CircleShapeImpl implements IShape {

	final double pi = 3.14;
	private double radius;

	@Override
	public void area() {
		
		double area = pi * Math.pow(radius, 2);
		System.out.println("Area of circle for the radius " + radius + " is " + area);
	}

	@Override
	public void perimeter() {
		double perimeter = 2 * pi * radius;
		System.out.println("Perimeter of circle for the radius " + radius + " is " + perimeter);
	}

	@Override
	public void input() {
		System.out.println("Enter the radius of circle :: ");
		Scanner sc = new Scanner(System.in);
		radius = sc.nextDouble();
		
	}

}
