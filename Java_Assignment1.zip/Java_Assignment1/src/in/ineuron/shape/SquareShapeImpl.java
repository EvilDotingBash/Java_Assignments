package in.ineuron.shape;

import java.util.Scanner;

public class SquareShapeImpl implements IShape {

	private double side;

	@Override
	public void area() {
		
		double area = Math.pow(side, 2);
		System.out.println("Area of square for side " + side + " is " + area);
	}

	@Override
	public void perimeter() {
		
		double perimeter = 4*side;
		System.out.println("Perimeter of square with sides " + side + " is " + perimeter);
	}

	@Override
	public void input() {
		System.out.println();
		System.out.println("Enter the side of square :: ");
		Scanner sc = new Scanner(System.in);
		side = sc.nextDouble();
		
	}

}
