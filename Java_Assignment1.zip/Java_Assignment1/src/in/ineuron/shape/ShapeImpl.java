package in.ineuron.shape;

public class ShapeImpl {

	public static void main(String[] args) {
		Shape s = new Shape();
		IShape circle = new CircleShapeImpl();
		s.shapes(circle);
		
		IShape triangle = new TriangleShapeImpl();
		s.shapes(triangle);
		
		IShape rectangle = new RectangleShapeImpl();
		s.shapes(rectangle);
		
		IShape square = new SquareShapeImpl();
		s.shapes(square);
		
		IShape rhombus = new RhombusShapeImpl();
		s.shapes(rhombus);
		
		
	}

}
