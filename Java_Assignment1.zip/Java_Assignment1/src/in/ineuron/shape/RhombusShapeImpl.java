package in.ineuron.shape;

import java.util.Scanner;

public class RhombusShapeImpl implements IShape {
	
	private double diagonal1;
	private double diagonal2;
	private double side;

	@Override
	public void area() {
		
		double area = (diagonal1*diagonal2)/2;
		System.out.println("Area of rhombus for diagonals " + diagonal1 + ", "+diagonal2+" is " + area);
	}

	@Override
	public void perimeter() {
		
		double perimeter =4*side;
		System.out.println("Perimeter of rhombus with side " + side +" is " + perimeter);
	}

	@Override
	public void input() {
		System.out.println();
		System.out.println("Enter the 2 diagonals of rhombus :: ");
		Scanner sc = new Scanner(System.in);
		diagonal1 = sc.nextDouble();
		diagonal2 = sc.nextDouble();
		System.out.println("Enter the side of rhombus :: ");
		side = sc.nextDouble();
		
	}

	

	

}
