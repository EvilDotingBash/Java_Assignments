package in.ineuron.shape;

import java.util.Scanner;

public class TriangleShapeImpl implements IShape {

	private double side1;
	private double side2;
	private double side3;

	@Override
	public void area() {
		double s = (side1 + side2 + side3) / 2;
		double a = s * (s - side1) * (s - side2) * (s - side3);
		double area = Math.sqrt(a);
		System.out.println("Area of triangle for sides " + side1 + ", " + side2 + "," + side3 + " is " + area);
	}

	@Override
	public void perimeter() {
		double perimeter = side1 + side2 + side3;
		System.out.println(
				"Perimeter of triangle with sides " + side1 + ", " + side2 + ", " + side3 + " is " + perimeter);
	}

	@Override
	public void input() {
		System.out.println();
		System.out.println("Enter the 3 sides of triangle :: ");
		Scanner sc = new Scanner(System.in);
		side1 = sc.nextDouble();
		side2 = sc.nextDouble();
		side3 = sc.nextDouble();
	}

}
