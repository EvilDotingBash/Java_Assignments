package in.ineuron.main;

class EvenNumberThread implements Runnable {

	@Override
	public void run() {
		for (int i = 2; i < 10; i += 2) {
			System.out.println("Even Number Thread " + i);
		}

	}

}

class OddNumberThread implements Runnable {

	@Override
	public void run() {
		for (int i = 3; i < 10; i += 2) {
			System.out.println("Odd Number Thread " + i);
		}

	}

}

public class TestApp {

	public static void main(String[] args) {
		Thread evenThread = new Thread(new EvenNumberThread());
		Thread oddThread = new Thread(new OddNumberThread());
		evenThread.start();
		oddThread.start();

	}

}
