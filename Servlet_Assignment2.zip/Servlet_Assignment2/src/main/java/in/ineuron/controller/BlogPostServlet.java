package in.ineuron.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.model.BlogPost;
import in.ineuron.service.IBlogPostService;
import in.ineuron.servicefactory.BlogPostServiceFactory;

@WebServlet("/blogpost/*")
public class BlogPostServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public BlogPostServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doProcess(request, response);

	}

	private void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		IBlogPostService blgPostService = BlogPostServiceFactory.getBlogPostService();

		if (request.getRequestURI().endsWith("createblog")) {

			String title = request.getParameter("title");
			String description = request.getParameter("description");
			String content = request.getParameter("content");

			BlogPost blogPost = new BlogPost();
			blogPost.setTitle(title);
			blogPost.setDescription(description);
			blogPost.setContent(content);

			String status = blgPostService.addBlogPost(blogPost);
			RequestDispatcher rd = null;
			if (status.equalsIgnoreCase("success")) {
				request.setAttribute("status", "success");
				rd = request.getRequestDispatcher("../insertResult.jsp");
				System.out.println(rd);
				rd.forward(request, response);
			} else {
				request.setAttribute("status", "failure");
				rd = request.getRequestDispatcher("../insertResult.jsp");
				rd.forward(request, response);
			}
		}

		if (request.getRequestURI().endsWith("searchBlog")) {

			String id = request.getParameter("id");

			BlogPost blogPost = blgPostService.searchBlogPost(Integer.parseInt(id));
			request.setAttribute("blogPost", blogPost);

			RequestDispatcher rd = null;
			rd = request.getRequestDispatcher("../display.jsp");
			rd.forward(request, response);

		}

		if (request.getRequestURI().endsWith("deleteBlog")) {

			String id = request.getParameter("id");

			String status = blgPostService.deleteBlogPost(Integer.parseInt(id));
			RequestDispatcher rd = null;
			if (status.equals("success")) {
				request.setAttribute("status", "success");
				rd = request.getRequestDispatcher("../deleteResult.jsp");
				rd.forward(request, response);
			} else if (status.equals("failure")) {
				request.setAttribute("status", "failure");
				rd = request.getRequestDispatcher("../deleteResult.jsp");
				rd.forward(request, response);

			} else {
				request.setAttribute("status", "not found");
				rd = request.getRequestDispatcher("../deleteResult.jsp");
				rd.forward(request, response);
			}

		}

		if (request.getRequestURI().endsWith("editBlog")) {
			String id = request.getParameter("id");

			BlogPost blogPost = blgPostService.searchBlogPost(Integer.parseInt(id));
			RequestDispatcher rd = null;
			if (blogPost != null) {
				request.setAttribute("blogPost", blogPost);
				rd = request.getRequestDispatcher("../updateRecord.jsp");
				rd.forward(request, response);
			}
		}

		if (request.getRequestURI().endsWith("updateForm")) {

			String id = request.getParameter("id");
			String title = request.getParameter("title");
			String description = request.getParameter("description");
			String content = request.getParameter("content");

			BlogPost blogPost = new BlogPost();
			blogPost.setId(Integer.parseInt(id));
			blogPost.setTitle(title);
			blogPost.setDescription(description);
			blogPost.setContent(content);

			String status = blgPostService.updateBlogPost(blogPost);
			RequestDispatcher rd = null;
			if (status.equalsIgnoreCase("success")) {
				rd = request.getRequestDispatcher("../../updatesuccess.jsp");
				rd.forward(request, response);
			} else {
				rd = request.getRequestDispatcher("../../updatesuccess.jsp");
				rd.forward(request, response);
			}

		}

	}
}
