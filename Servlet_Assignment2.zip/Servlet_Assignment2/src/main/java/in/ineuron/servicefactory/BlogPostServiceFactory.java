package in.ineuron.servicefactory;

import in.ineuron.service.BlogPostServiceImpl;
import in.ineuron.service.IBlogPostService;

public class BlogPostServiceFactory {

	public BlogPostServiceFactory() {
	}
	
private static IBlogPostService blogPostService = null;
	
	public static IBlogPostService getBlogPostService() {
		
		if (blogPostService ==null) {
			blogPostService = new BlogPostServiceImpl();
		}
		
		return blogPostService;
		
	}
}
