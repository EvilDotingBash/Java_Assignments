package in.ineuron.daofactory;

import in.ineuron.dao.BlogPostDaoImpl;
import in.ineuron.dao.IBlogPostDao;

public class BlogPostDaoFactory {

	public BlogPostDaoFactory() {
	}
	private static IBlogPostDao blogPostDao = null;
	
	public static IBlogPostDao getBlogPostDao() {

		if (blogPostDao == null) {
			blogPostDao = new BlogPostDaoImpl();
		}
		return blogPostDao;
		
	}

}
