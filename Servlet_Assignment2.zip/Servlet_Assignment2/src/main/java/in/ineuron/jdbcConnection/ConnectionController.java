package in.ineuron.jdbcConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class ConnectionController {
	private ConnectionController() {
	}
	
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static Connection getJdbcConnection() throws SQLException, IOException {
		String fileLoc = "D:\\Assignment\\Servlet_Assignment2\\src\\main\\java\\in\\ineuron\\properties\\application.properties";
		HikariConfig config = new HikariConfig(fileLoc);
		HikariDataSource dataSource = new HikariDataSource(config);
		
		return dataSource.getConnection();
		
	}
}

/*
 * String fileLoc =
 * "D:\\Assignment\\Servlet_Assignment2\\src\\main\\java\\in\\ineuron\\properties\\application.properties";
 * FileInputStream fis = new FileInputStream(fileLoc); Properties properties =
 * new Properties(); properties.load(fis);
 * 
 * String url = properties.getProperty("jdbcUrl"); String username =
 * properties.getProperty("user"); String password =
 * properties.getProperty("password");
 * 
 * return DriverManager.getConnection(url, username, password);
 */