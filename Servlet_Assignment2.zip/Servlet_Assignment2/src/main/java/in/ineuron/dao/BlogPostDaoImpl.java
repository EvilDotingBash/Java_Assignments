package in.ineuron.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import in.ineuron.jdbcConnection.ConnectionController;
import in.ineuron.model.BlogPost;

public class BlogPostDaoImpl implements IBlogPostDao {

	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet resultSet = null;
	@Override
	public String addBlogPost(BlogPost blogPost) {
		
		String sqlInsertQuery = "insert into blogpost(title,description,content)values(?,?,?)";
		try {
			connection = ConnectionController.getJdbcConnection();
			
			if (connection!=null) 
				pstmt = connection.prepareStatement(sqlInsertQuery);
			
			if(pstmt!=null)
			{
				pstmt.setString(1, blogPost.getTitle());
				pstmt.setString(2, blogPost.getDescription());
				pstmt.setString(3, blogPost.getContent());
				
				int rowAffected = pstmt.executeUpdate();
				
				if (rowAffected == 1) {
					System.out.println("success");
					return "success";
				}
			}
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		System.out.println("failure");
		return "failure";
	}

	@Override
	public BlogPost searchBlogPost(Integer id) {
		String sqlSelectQuery = "select id,title,description,content from blogpost where id = ?";
		BlogPost blogPost = null;
		try {
			connection = ConnectionController.getJdbcConnection();
			
			if (connection!=null) 
				pstmt = connection.prepareStatement(sqlSelectQuery);
			
			if(pstmt!=null) 
				pstmt.setInt(1, id);
			if (pstmt!=null) 
				resultSet = pstmt.executeQuery();
				
			if (resultSet!=null) {
				if (resultSet.next()) {
					blogPost = new BlogPost();
					
					blogPost.setId(resultSet.getInt(1));
					blogPost.setTitle(resultSet.getString(2));
					blogPost.setDescription(resultSet.getString(3));
					blogPost.setContent(resultSet.getString(4));
					return blogPost;
				}
			}
				
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
	
		return blogPost;
	}
	
	@Override
	public String updateBlogPost(BlogPost blogPost) {
		String sqlUpdateQuery = "update blogpost set title = ?, description = ?,content=? where id = ?";
		try {
			connection = ConnectionController.getJdbcConnection();
			
			if (connection!=null) 
				pstmt = connection.prepareStatement(sqlUpdateQuery);
			
			if(pstmt!=null)
			{
				pstmt.setString(1, blogPost.getTitle());
				pstmt.setString(2, blogPost.getDescription());
				pstmt.setString(3, blogPost.getContent());
				pstmt.setInt(4, blogPost.getId());
				
				int rowAffected = pstmt.executeUpdate();
				if (rowAffected == 1) {
					return "success";
				}
			}
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		return "failure";
	}

	@Override
	public String deleteBlogPost(Integer id) {
		String sqlDeleteQuery = "delete from blogpost where id = ?";
		try {
			connection = ConnectionController.getJdbcConnection();
			
			if (connection!=null) 
				pstmt = connection.prepareStatement(sqlDeleteQuery);
			
			if(pstmt!=null)
			{
				pstmt.setInt(1, id);
				
				int rowAffected = pstmt.executeUpdate();
				
				if (rowAffected == 1) {
					return "success";
				}else {
					return "not found";
				}
			}
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		//	return "failure";
		}
		return "failure";
	}

}
