package in.ineuron.dao;

import in.ineuron.model.BlogPost;

public interface IBlogPostDao {

	public String addBlogPost(BlogPost blogPost);

	public BlogPost searchBlogPost(Integer id);

	public String updateBlogPost(BlogPost blogPost);

	public String deleteBlogPost(Integer id);
}
