package in.ineuron.service;

import in.ineuron.dao.IBlogPostDao;
import in.ineuron.daofactory.BlogPostDaoFactory;
import in.ineuron.model.BlogPost;

public class BlogPostServiceImpl implements IBlogPostService {

	private IBlogPostDao blogPostDao=null;
	
	@Override
	public String addBlogPost(BlogPost blogPost) {
		blogPostDao = BlogPostDaoFactory.getBlogPostDao();
		return blogPostDao.addBlogPost(blogPost);
	}

	@Override
	public BlogPost searchBlogPost(Integer id) {
		blogPostDao = BlogPostDaoFactory.getBlogPostDao();
		return blogPostDao.searchBlogPost(id);
	}

	@Override
	public String updateBlogPost(BlogPost blogPost) {
		blogPostDao = BlogPostDaoFactory.getBlogPostDao();
		return blogPostDao.updateBlogPost(blogPost);
	}	

	@Override
	public String deleteBlogPost(Integer id) {
		blogPostDao = BlogPostDaoFactory.getBlogPostDao();
		return blogPostDao.deleteBlogPost(id);
	}


}
