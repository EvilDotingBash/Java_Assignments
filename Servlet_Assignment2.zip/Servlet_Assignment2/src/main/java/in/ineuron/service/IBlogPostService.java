package in.ineuron.service;

import in.ineuron.model.BlogPost;

public interface IBlogPostService {

	public String addBlogPost(BlogPost blogPost);

	public BlogPost searchBlogPost(Integer id);

	public String updateBlogPost(BlogPost blogPost);

	public String deleteBlogPost(Integer id);
}
