package in.ineuron.test;

import java.util.Scanner;

public class IntegerTest {

	int number;

	public void input() {
		System.out.println("Enter the number to be checked :: ");
		Scanner sc = new Scanner(System.in);
		number = sc.nextInt();
	}

	public void check() throws NegativeIntegerException {
		{
			if (number > 0) {
				System.out.println(number + " is positive");
			} else {
				NegativeIntegerException exception = new NegativeIntegerException(
						"Entered number is negative...Sorry! Not Allowed");
				System.out.println(exception.getMessage());
				throw exception;
			}
		}
	}
}
