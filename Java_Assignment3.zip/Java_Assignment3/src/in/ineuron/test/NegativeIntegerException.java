package in.ineuron.test;

public class NegativeIntegerException extends Exception {

	public NegativeIntegerException(String msg) {
		super(msg);
	}
}
