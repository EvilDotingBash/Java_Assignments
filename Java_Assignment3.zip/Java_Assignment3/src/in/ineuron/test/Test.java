package in.ineuron.test;

public class Test {

	public static void main(String[] args) {

		IntegerTest test = new IntegerTest();
		try {
			test.input();
			test.check();
		} catch (NegativeIntegerException e) {
			e.printStackTrace();
		}
	}
}
