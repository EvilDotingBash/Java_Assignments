package in.ineuron.main;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class TestApp {

	private static final int MAX_SIZE = 10;
	private static final int MAX_NUMBER = 100;
	private static final int MAX_NUMBER_TO_PRODUCE = 20;
	private static int sum = 0;

	private static Queue<Integer> queue = new LinkedList<>();
	private static Object lock = new Object();

	public static void main(String[] args) {

		Thread producerThread = new Thread(new Producer());
		Thread consumerThread = new Thread(new Consumer());

		producerThread.start();
		consumerThread.start();
	}

	static class Producer implements Runnable {
		private Random random = new Random();

		@Override
		public void run() {
			int i = 0;
			while (true) {
				synchronized (lock) {
					while (i <= MAX_NUMBER_TO_PRODUCE) {
						while (queue.size() >= MAX_SIZE) {
							try {
								lock.wait();
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}

						int number = random.nextInt(MAX_NUMBER);
						System.out.println("Produced: " + number);
						queue.add(number);

						i++;
						lock.notifyAll();
					}
				}
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	static class Consumer implements Runnable {

		@Override
		public void run() {
			int i=0;
			while (true) {
				synchronized (lock) {
					while (i <= MAX_NUMBER_TO_PRODUCE) {
						while (queue.isEmpty()) {
							try {
								lock.wait();
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}

						int number = queue.poll();
						System.out.println("Consumed: " + number);
						calculateSum(number);

						i++;
						lock.notifyAll();
					}
				}
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		private void calculateSum(int number) {

			sum += number;
			System.out.println("Sum: " + sum);
		}

	}
}