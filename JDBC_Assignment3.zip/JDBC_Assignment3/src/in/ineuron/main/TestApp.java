package in.ineuron.main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TestApp {
    private static final String DATABASE_URL = "jdbc:postgresql://localhost:5433/student";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";
    private static final String SQL_INSERT_QUERY = "INSERT INTO students (id, name, age, address) VALUES (?, ?, ?, ?)";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD)) {
            // Read input data from a file
            String inputFile = "input.txt";
            try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
                String line;
                PreparedStatement pstmt = connection.prepareStatement(SQL_INSERT_QUERY);

                while ((line = reader.readLine()) != null) {
                    String[] values = line.split(",");
                    String id = values[0].trim();
                    String name = values[1].trim();
                    String age = values[2].trim();
                    String address = values[3].trim();

                    pstmt.setString(1, id);
                    pstmt.setString(2, name);
                    pstmt.setString(3, age);
                    pstmt.setString(4, address);

                    pstmt.addBatch();
                }

                int[] updateCounts = pstmt.executeBatch();
                System.out.println("Batch update executed successfully.");

                for (int count : updateCounts) {
                    System.out.println("Rows affected: " + count);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}