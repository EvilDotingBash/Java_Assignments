package in.ineuron.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import JdbcConnection.ConnectionController;


@WebServlet("/select")
public class SelectApp extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public SelectApp() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String sqlSelectQuery = "Select id,name,age,address from students";
		try {
			Connection connection = ConnectionController.getJdbcConnection();
			PreparedStatement pstmt = connection.prepareStatement(sqlSelectQuery);
			ResultSet resultSet = pstmt.executeQuery();
			PrintWriter out = response.getWriter();
			out.print("<html>");
			out.print("<body>");
			out.print("<center>");
			out.print("<h1 style='color:green; text-align:center;'>Student Details</h1>");
			out.print("<table border='1'>");
			out.print("<tr><td>ID</td><td>NAME</td><td>AGE</td><td>ADDRESS</td>");
			
			while (resultSet.next()) {
				out.print("<tr><td>");
				out.print(resultSet.getInt(1));
				out.print("</td><td>");
				out.print(resultSet.getString(2));
				out.print("</td><td>");
				out.print(resultSet.getInt(3));
				out.print("</td><td>");
				out.print(resultSet.getString(4));
				out.print("</td></tr>");
			}
			out.print("</table>");
			out.print("</center>");
			out.print("</body>");
			out.print("</html>");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
