package in.ineuron.main;

import java.io.IOException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import in.ineuron.model.Employee;
import in.ineuron.util.HibernateUtil;

public class SaveSelectApp {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {

		Session session = null;
		Transaction transaction = null;
		boolean flag = false;

		try {
			session = HibernateUtil.getSession();
			if (session != null) {
				transaction = session.beginTransaction();
			}
			if (transaction!=null) {
				
				Employee employee = new Employee();
				employee.setId(4);
				employee.setName("Rahul");
				employee.setAge(32);
				employee.setSalary(30000);
				
				session.save(employee);
				flag=true;
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (flag) {
				transaction.commit();		
				System.out.println("Object saved to database...");
			} else {
				transaction.rollback();
				System.out.println("Object not saved to database...");
			}
			/*
			 * HibernateUtil.closeSession(session); HibernateUtil.closeSessionFactory();
			 */
		}
		try {
			Query<Employee> query = session.createQuery("FROM in.ineuron.model.Employee");
			List<Employee> products = query.list();
			products.forEach(System.out::println);

		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}
		
	}

}