package in.ineuron.main;

import java.io.IOException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;

import in.ineuron.model.Employee;
import in.ineuron.util.HibernateUtil;

public class SelectApp {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {

		Session session = null;
		try {
			session = HibernateUtil.getSession();
			Query<Employee> query = session.createQuery("FROM in.ineuron.model.Employee");
			List<Employee> products = query.list();
			products.forEach(System.out::println);

		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}

	}
}
/*
 * Session session = null; Integer id = 2; try { session =
 * HibernateUtil.getSession(); if (session != null) { Student student =
 * session.get(Student.class, id); if (student != null) {
 * System.out.println(student); } else {
 * System.out.println("Record not found for the given id :: " + id); } } } catch
 * (HibernateException e) { e.printStackTrace(); } catch (Exception e) {
 * e.printStackTrace(); } finally {
 * 
 * HibernateUtil.closeSession(session); HibernateUtil.closeSessionFactory(); }
 * 
 * }
 */
